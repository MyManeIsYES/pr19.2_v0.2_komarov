package com.bignerdranch.android.pr1923

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    lateinit var editname:EditText
    lateinit var editage:EditText
    lateinit var adapter:ArrayAdapter<User>
    var name:String=""
    var age:Int = 0
    lateinit var users:ArrayList<User>
    lateinit var listwiev:ListView
    lateinit var save: Button
    lateinit var add: Button
    lateinit var open: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editname=findViewById(R.id.editname)
        editage=findViewById(R.id.editage)
        listwiev=findViewById(R.id.ListView)
        //save=findViewById(R.id.saveButton)
        //add=findViewById(R.id.addButton)
        //open=findViewById(R.id.openButton)
        users= ArrayList()
        adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,users)
        listwiev.adapter = adapter as ArrayAdapter<User>


        /*add.setOnClickListener { view: View ->
            val name = editname.text.toString()
            val age = editage.text.toString().toInt()
            val user = User(name, age)
            users.add(user)
            (adapter as ArrayAdapter<User>).notifyDataSetChanged()
            listwiev.adapter = adapter as ArrayAdapter<User>
        }
        save.setOnClickListener { view: View ->
            val jsonHelper=JSONHelper()
            val result = jsonHelper.exportToJSON(this, users)
            if (result) {
                Toast.makeText(this, "Данные сохранены",
                Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Не удалось сохранить данны",
                Toast.LENGTH_LONG).show()
            }
        }
        open.setOnClickListener { view: View ->
            val jsonHelper=JSONHelper()
            users = jsonHelper.importFromJSON(this) as ArrayList<User>
            if (users != null) {
                (adapter as ArrayAdapter<User>).clear()
                (adapter as ArrayAdapter<User>).addAll(users)
                listwiev.adapter = adapter as ArrayAdapter<User>
                Toast.makeText(this, "Данные восстановлены",
                Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Не удалось открыть данные",
                Toast.LENGTH_LONG).show()
            }*/
        }
        fun addUser(view: View) {

            val name = editname.text.toString()
            val age = editage.text.toString().toInt()
            val user = User(name, age)
            users.add(user)
            (adapter).notifyDataSetChanged()
        }

        fun save(view: View) {
            val jsonHelper=JSONHelper()
            val result = jsonHelper.exportToJSON(this, users)
            if (result) {
                Toast.makeText(this, "Данные восстановлены",
                    Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Не удалось сохранить данны",
                    Toast.LENGTH_LONG).show()
            }
        }

        fun open(view: View) {
            val jsonHelper=JSONHelper()
            users = jsonHelper.importFromJSON(this) as ArrayList<User>
            if (users != null) {
                (adapter).clear()
                (adapter).addAll(users)
                Toast.makeText(this, "Данные восстановлены",
                    Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Не удалось открыть данные",
                    Toast.LENGTH_LONG).show()
            }
        }
    }
