package com.bignerdranch.android.pr1923

import android.content.Context
import java.io.IOException
import java.io.InputStreamReader
import com.google.gson.Gson

class JSONHelper {
    private val FILE_NAME="data.json"
    fun exportToJSON(context: Context,dataList: List<User?>):Boolean{
        val gson=Gson()
        val dataItems=DataItems()
        dataItems.users=dataList
        val jsonString:String=gson.toJson(dataItems)
        try {
            context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE).use { fileOutputStream ->
                fileOutputStream.write(jsonString.toByteArray())
                return true
            }
        }catch (e: Exception){
            e.printStackTrace()
        }
        return false
    }
    fun importFromJSON(context: Context):List<User?>?{
        try {
            context.openFileInput(FILE_NAME).use { fileOutputStream ->
                InputStreamReader(fileOutputStream).use { streamReader ->
                    val gson=Gson()
                    val dataItems: DataItems=gson.fromJson(streamReader, DataItems::class.java)
                    return  dataItems.users
                }
            }
        }catch (ex: IOException){
            ex.printStackTrace()
        }
        return  null
    }
    private  class DataItems{
        var users:List<User?>?=null
    }
}